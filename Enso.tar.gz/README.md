# Enso Speedrun Auto Bot

An automated bot for completing daily tasks on the Enso Speedrun platform, including DeFiDex project creation and AI chat interactions.

## Features

- Automated DeFiDex project creation (5x daily)
- Automated AI chat interactions (5x daily)
- Secure wallet authentication
- Proxy rotation support
- Automatic daily task execution
- Detailed logging and error handling

## Prerequisites

- Node.js v18+
- npm or yarn
- Ethereum private keys (for authentication)
- Enso user IDs and Zealy user IDs
- (Optional) Proxies in `proxies.txt`

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/airdropinsiders/Enso-Auto-Bot.git
   cd Enso-Auto-Bot
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file based on `.env.example`:
   ```bash
   cp .env.example .env
   ```

4. Edit the `.env` file with your account details:
   ```
   PRIVATE_KEY_1=0xYourPrivateKey1
   USER_ID_1=0xYourEthereumAddress1
   ZEALY_USER_ID_1=your-zealy-uuid-1

   PRIVATE_KEY_2=0xYourPrivateKey2
   USER_ID_2=0xYourEthereumAddress2
   ZEALY_USER_ID_2=your-zealy-uuid-2
   ```

5. (Optional) Add proxies to `proxies.txt` (one per line):
   ```
   http://user:pass@host:port
   socks5://user:pass@host:port
   ```

## Usage

Run the bot:
```bash
node index.js
```

The bot will:
1. Validate your accounts
2. Perform daily DeFiDex project creations
3. Complete AI chat interactions
4. Automatically restart daily

## Configuration

You can modify these constants in the code:
- `DELAY_MS`: Delay between actions (default: 1000ms)
- `DEFIDEX_DAILY_LIMIT`: Max DeFiDex creations per day (default: 5)
- `CHAT_DAILY_LIMIT`: Max AI chats per day (default: 5)
- `MAX_RETRIES`: Max retry attempts for failed requests
- `RANDOM_QUERIES`: Customize AI chat questions

## Package Dependencies

The project uses the following main packages:
- `axios` for HTTP requests
- `ethers` for wallet operations
- `dotenv` for environment variables
- `random-useragent` for request headers
- `https-proxy-agent` for proxy support

See `package.json` for full dependency list.

## Disclaimer

This bot is for educational purposes only. Use at your own risk. The developers are not responsible for any account restrictions or penalties that may occur from using this bot.

## Support

For issues or feature requests, please open an issue on [GitHub](https://github.com/airdropinsiders/Enso-Auto-Bot/issues).